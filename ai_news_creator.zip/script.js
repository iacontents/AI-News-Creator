document.addEventListener('DOMContentLoaded', function() {
    console.log('AI News Creator is ready!');
});