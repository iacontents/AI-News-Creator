# AI News Creator
This is an AI-powered news website that automatically summarizes news and provides real-time updates.

## Features
- AI-generated news summaries
- PayPal integration for premium content
- Secure authentication with email verification

## Setup
1. Install dependencies: `npm install`
2. Run the server: `node server.js`
3. Deploy to Netlify or any hosting provider
